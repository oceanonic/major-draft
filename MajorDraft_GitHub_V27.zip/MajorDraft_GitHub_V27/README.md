# Major Draft V27

A static browser game. No server or build step required.

## Publish with GitHub Pages

1. Create a new GitHub repository (for example `major-draft`).
2. Upload **index.html** to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. GitHub will provide the public Pages URL.

The game is self-contained in `index.html`, so no npm install or hosting backend is needed.
